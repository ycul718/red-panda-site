# 小貓熊物種比較

本專案提供兩種小貓熊物種（喜馬拉雅小貓熊與中華小貓熊）的外觀、棲息地、遺傳等比較資訊，並使用 GitHub Pages 發佈網頁。

## 線上瀏覽

請將此專案部署於 GitHub Pages，網址範例如：

```
https://your-username.github.io/red-panda-site/
```

## 使用

HTML 文件可直接用於教學展示、科展資料、或配合 pandas 網頁爬蟲練習。
